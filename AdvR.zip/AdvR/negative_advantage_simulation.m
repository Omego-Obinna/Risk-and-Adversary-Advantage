% Monte Carlo Simulation to Increase Adversary's Advantage with Minimum Risk

% Set the random seed for reproducibility
rng('default'); % or rng(1);

% Parameters setup
numSimulations = 10000;  % Number of simulation iterations

% Define ranges for parameters (in £)
B_A_leak_range = [5000000, 8000000];    % Increased to higher values
C_A_look_range = [50000, 200000];       % Decreased lower limit
B_U_harmony_range = [5000000, 10000000];% Unchanged
B_U_hide_range = [5000000, 7000000];    % Increased to higher values
C_U_hide_range = [500000, 1000000];     % Decreased to lower values
C_U_leak_range = [6000000, 12000000];   % Unchanged

% Set the minimum adversary's advantage
Adv_min = 0.01; % Minimum adversary's advantage (adjust as needed)

% Initialize arrays to store simulation results
Adv_values = zeros(1, numSimulations);
R_values = zeros(1, numSimulations);
p_values = zeros(1, numSimulations);
q_values = zeros(1, numSimulations);

% Shape parameters for Beta distribution (further skewed towards lower values)
a_beta = 1; % Decreased alpha to 1
b_beta = 5; % Keep beta the same

% Monte Carlo Simulation
for i = 1:numSimulations
    % Randomly sample values from parameter ranges
    B_A_leak = B_A_leak_range(1) + diff(B_A_leak_range) * rand;
    C_A_look = C_A_look_range(1) + diff(C_A_look_range) * rand;
    B_U_harmony = B_U_harmony_range(1) + diff(B_U_harmony_range) * rand;
    B_U_hide = B_U_hide_range(1) + diff(B_U_hide_range) * rand;
    C_U_hide = C_U_hide_range(1) + diff(C_U_hide_range) * rand;
    C_U_leak = C_U_leak_range(1) + diff(C_U_leak_range) * rand;
    
    % Sample beta_U from a Beta distribution further skewed towards lower values
    beta_U = randg(a_beta);
    beta_U = beta_U / (beta_U + randg(b_beta));
    
    % Calculate mixed strategy probabilities
    p_star = (B_A_leak - C_A_look) / B_A_leak;
    q_star = (B_U_harmony - B_U_hide + C_U_hide) / (C_U_leak + B_U_harmony);
    
    % Ensure probabilities are within [0,1]
    p_star = min(max(p_star, 0), 1);
    q_star = min(max(q_star, 0), 1);

    % Calculate success probabilities based on Hide or Not Hide
    Pr_A_success_Hide_U = p_star * (1 - beta_U);
    Pr_A_success_NotHide_U = p_star * (1 - (1 - q_star) * beta_U);

    % Calculate adversary's advantage
    Adv = abs(Pr_A_success_Hide_U - Pr_A_success_NotHide_U);

    % Enforce the minimum threshold for Adv
    if Adv < Adv_min
        Adv = Adv_min;
    end

    % Calculate risk based on advantage and the impact
    I_alpha = C_U_leak + B_U_harmony;  % Impact factor in £
    R = I_alpha * Adv;                 % Calculated risk directly in £

    % Store values for 3D plotting
    Adv_values(i) = Adv;
    R_values(i) = R;
    p_values(i) = p_star;
    q_values(i) = q_star;
end

% 3D Scatter Plot for Increased Adversary's Advantage Scenario
figure;
scatter3(p_values, q_values, R_values, 36, Adv_values, 'filled');
title('Increased Adversary''s Advantage with Minimum Risk');
xlabel('Probability of \mathcal{A} Attacking (p^*)');
ylabel('Probability of \mathcal{U} Hiding (q^*)');
zlabel('Risk (R in £)');
colorbar; % Adds a colorbar to show advantage levels
colormap(parula); % Set colormap to Parula for better visibility
view(3); % Display plot in 3D
grid on;

% Display statistics of Adversary's Advantage and Risk values
disp(['Mean Adversary''s Advantage: ', num2str(mean(Adv_values), '%.4f')]);
disp(['Min Adversary''s Advantage: ', num2str(min(Adv_values), '%.4f')]);
disp(['Max Adversary''s Advantage: ', num2str(max(Adv_values), '%.4f')]);
disp(['Mean Risk: £', num2str(mean(R_values), '%.2f')]);
disp(['Min Risk: £', num2str(min(R_values), '%.2f')]);
disp(['Max Risk: £', num2str(max(R_values), '%.2f')]);

% Optional: Plot histogram of Adversary's Advantage values
figure;
histogram(Adv_values, 50);
title('Distribution of Adversary''s Advantage');
xlabel('Adversary''s Advantage (Adv)');
ylabel('Frequency');
